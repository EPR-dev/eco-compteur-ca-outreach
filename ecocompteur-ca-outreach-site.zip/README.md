# Eco-Compteur California Outreach Map (500+ Targets)

Static mini-site for GitHub Pages.

**Files**
- `index.html` – Leaflet map with clustering, static legend, layer toggles
- `data/targets.json` – 500+ outreach targets (city agencies, BIDs, universities, NGOs, transit, regional/state)
- `Eco_Compteur_California_Outreach_500plus_site.csv` – same data as CSV (for editing)

**Deploy on GitHub Pages**
1) Create a new **public** repo (e.g., `eco-compteur-ca-outreach`).  
2) Upload the contents of this folder (`index.html`, `data/targets.json`, CSV).  
3) In **Settings → Pages**: Source = *Deploy from a branch*; select `main` (or `master`) and `/root`.  
4) Your site will be served at `https://<your-username>.github.io/eco-compteur-ca-outreach/`.

**Editing data**
- Update `data/targets.json` in place (valid JSON).  
- Or edit the CSV locally and convert to JSON, preserving the schema:  
  `[{"name":"Los Angeles – Transportation Department","lat":34.053,"lon":-118.243,"category":"City Agency"}, ...]`

Notes: The legend is **static** (doesn’t change with toggles). Libraries load from CDNs.
